<?php

include ('header.html');

?>

<!DOCTYPE html>
<html lang="en">
<div class="container">
<div class="mainsnacks">
	<div class="row">
		<div class="col-md-6">

			<div class="card" style="width: 30rem; ">
			<a href="#">
			  <img class="card-img-top" src="pictures/popcorn.jpg" alt="popcorn" height="270px">
			  </a>
			  <div class="card-body">
				<p class="card-text">Popcorn</p>
			  </div>
			</div>
		</div>
			
	<div class="col-md-6">

			<div class="card" style="width: 30rem; ">
			<a href="#">
			  <img class="card-img-top" src="pictures/nachos.jpg" alt="nachos" height="270px">
			  </a>
			  <div class="card-body">
				<p class="card-text">Nachos</p>
			  </div>
			</div>
		</div>
	</div>
	<div class="row">
	<div class="col-md-12">

			<div class="card" style="width: 30rem;">
			<a href="#">
			  <img class="card-img-top" src="pictures/cola.jpg" alt="Coca Cola" height="270px">
			  </a>
			  <div class="card-body">
				<p class="card-text">Coca Cola</p>
			   </div>
			</div>
		</div>
		</div>