var navbar = "<nav><ul>";

navbar = navbar+ "<li>This is nav bar</li></ul>";

$('#header').html(navbar);