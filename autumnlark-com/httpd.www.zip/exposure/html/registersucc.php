<!DOCTYPE html>
<html>
	<head>
		<title>success</title>
		<meta name="content-type"; charset=UTF-8">
	</head>
	<body>
		<div>
            <h1>success！</h1>
			<a href="login.php">login</a> 
		</div>
	</body>
</html>